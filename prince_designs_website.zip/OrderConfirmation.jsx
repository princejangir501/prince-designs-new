import React from "react";

export default function OrderConfirmation() {
  return (
    <div className="p-8 text-center">
      <h2 className="text-3xl font-bold text-green-600 mb-4">Order Confirmed!</h2>
      <p className="text-lg">Thank you for shopping with Prince Designs. Your order will be delivered soon.</p>
    </div>
  );
}
