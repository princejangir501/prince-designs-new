import React from "react";

export default function PaymentPage() {
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold mb-4">Payment Page</h2>
      <form className="space-y-4">
        <input type="text" placeholder="Card Number" className="w-full p-2 border" />
        <input type="text" placeholder="Name on Card" className="w-full p-2 border" />
        <input type="text" placeholder="Expiry Date" className="w-full p-2 border" />
        <input type="text" placeholder="CVV" className="w-full p-2 border" />
        <button type="submit" className="bg-pink-500 text-white px-4 py-2 rounded">Pay Now</button>
      </form>
    </div>
  );
}
